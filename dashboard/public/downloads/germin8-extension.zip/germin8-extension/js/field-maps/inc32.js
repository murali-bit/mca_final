// INC-32 / SPICe+ Part B — New Company Registration field map
// Categories align with the MCA form sections so the popup can render them grouped.

if (typeof window !== 'undefined' && window.INC32_CATEGORIES) {
  // already loaded by the manifest content script — nothing to do.
} else {
var INC32_CATEGORIES = [
  {
    id: "company_details",
    label: "Company Details",
    icon: "building",
    fields: [
      {
        key: "companyType",
        label: "Type of company",
        selector: "#guideContainer-rootPanel-panel_2017717670_cop-panel-guidedropdownlist___widget, select[name='guideContainer-rootPanel-panel_2017717670_cop-panel-guidedropdownlist___jqName']",
        type: "select",
        dataKey: "Company type",
        required: true,
      },
      {
        key: "companyClass",
        label: "Class of the company",
        selector: "#guideContainer-rootPanel-panel_2017717670_cop-panel-guidedropdownlist_co___widget, select[name='guideContainer-rootPanel-panel_2017717670_cop-panel-guidedropdownlist_co___jqName']",
        type: "select",
        dataKey: "Company class",
        required: true,
      },
      {
        key: "companyCategory",
        label: "Category of the company",
        selector: "#guideContainer-rootPanel-panel_2017717670_cop-panel-guidedropdownlist_co_1813708729___widget, select[name='guideContainer-rootPanel-panel_2017717670_cop-panel-guidedropdownlist_co_1813708729___jqName']",
        type: "select",
        dataKey: "Company category",
        required: true,
      },
      {
        key: "companySubCategory",
        label: "Sub-category of the company",
        selector: "#guideContainer-rootPanel-panel_2017717670_cop-panel-guidedropdownlist_co_175619313___widget, select[name='guideContainer-rootPanel-panel_2017717670_cop-panel-guidedropdownlist_co_175619313___jqName']",
        type: "select",
        dataKey: "Company sub-category",
        required: true,
      },
      {
        key: "llpin",
        label: "LLPIN",
        selector: "#guideContainer-rootPanel-panel_2017717670_cop-panel-guidetextbox_1884163___widget",
        type: "text",
        dataKey: "LLPIN",
        optional: true,
      },
      {
        key: "llpinCinType",
        label: "LLPIN / CIN type",
        selector: "#guideContainer-rootPanel-panel_2017717670_cop-panel-guidedropdownlist_co_226026912___widget",
        type: "select",
        dataKey: "LLPIN/CIN type",
        optional: true,
      },
    ],
  },
  {
    id: "proposed_names",
    label: "Proposed Names",
    icon: "pen",
    fields: [
      {
        key: "proposedName1",
        label: "Proposed Name I",
        selector: "#guideContainer-rootPanel-panel_2017717670_cop-panel_copy-panel-panel-guidetextbox_1884163___widget, input[name='guideContainer-rootPanel-panel_2017717670_cop-panel_copy-panel-panel-guidetextbox_1884163___jqName']",
        type: "text",
        dataKey: "proposedName1",
        required: true,
      },
      {
        key: "proposedName2",
        label: "Proposed Name II",
        selector: "#guideContainer-rootPanel-panel_2017717670_cop-panel_copy-panel-panel_2003762916-guidetextbox_4394968___widget, input[name='guideContainer-rootPanel-panel_2017717670_cop-panel_copy-panel-panel_2003762916-guidetextbox_4394968___jqName']",
        type: "text",
        dataKey: "proposedName2",
        optional: true,
      },
      {
        key: "submitOption",
        label: "Submission type",
        selector: "input[name='submit-radio-button']",
        type: "radio",
        dataKey: "Submission type",
        choices: ["Submit application for name reservation", "Proceed for Incorporation"],
        required: true,
      },
    ],
  },
  {
    id: "nic_activity",
    label: "NIC / Industrial Activity",
    icon: "sliders",
    fields: [
      {
        key: "nicCode",
        label: "Main NIC Code (sub-class)",
        selector: "#guideContainer-rootPanel-panel_2017717670_cop-panel-panel_77849537-panel_896788791_copy-guidetextbox___widget",
        type: "text",
        dataKey: "NIC code",
        required: true,
      },
      {
        key: "mainActivity",
        label: "Description of main sub-class",
        selector: "#guideContainer-rootPanel-panel_2017717670_cop-panel-panel_77849537-panel_896788791_copy-guidetextbox_3059927___widget",
        type: "textarea",
        dataKey: "Business activity",
        required: true,
      },
      {
        key: "nicCode1",
        label: "NIC Code 1",
        selector: "#guideContainer-rootPanel-panel_1558366475_cop-guidetextbox_copy_831679774___widget, #guideContainer-rootPanel-panel-NICCode11623102030812___widget",
        type: "text",
        dataKey: "NIC Code 1",
        optional: true,
      },
      {
        key: "nicCode1Desc",
        label: "NIC Code 1 – Description",
        selector: "#guideContainer-rootPanel-panel_1558366475_cop-guidetextbox_copy_co___widget, #guideContainer-rootPanel-panel-Description11623102077810___widget",
        type: "text",
        dataKey: "NIC Code 1 Description",
        optional: true,
      },
      {
        key: "nicCode2",
        label: "NIC Code 2",
        selector: "#guideContainer-rootPanel-panel_1558366475_cop-guidetextbox___widget, #guideContainer-rootPanel-panel-NICCode21623102035619___widget",
        type: "text",
        dataKey: "NIC Code 2",
        optional: true,
      },
      {
        key: "nicCode2Desc",
        label: "NIC Code 2 – Description",
        selector: "#guideContainer-rootPanel-panel_1558366475_cop-guidetextbox_copy___widget, #guideContainer-rootPanel-panel-Description21623102080197___widget",
        type: "text",
        dataKey: "NIC Code 2 Description",
        optional: true,
      },
      {
        key: "nicCode3",
        label: "NIC Code 3",
        selector: "#guideContainer-rootPanel-panel_1558366475_cop-guidetextbox_copy_385397651___widget, #guideContainer-rootPanel-panel-NICCode31623102074219___widget",
        type: "text",
        dataKey: "NIC Code 3",
        optional: true,
      },
      {
        key: "nicCode3Desc",
        label: "NIC Code 3 – Description",
        selector: "#guideContainer-rootPanel-panel_1558366475_cop-guidetextbox_copy_1865585167___widget, #guideContainer-rootPanel-panel-Description31623102082918___widget",
        type: "text",
        dataKey: "NIC Code 3 Description",
        optional: true,
      },
    ],
  },
  {
    id: "attachments",
    label: "Attachments",
    icon: "paperclip",
    fields: [
      {
        key: "optionalAttachment",
        label: "Optional attachment(s)",
        selector: "#guideContainer-rootPanel-panel_2017717670_cop-panel_copy_202561516-fileuploadwithplaceh_924283015___widget",
        type: "file",
        dataKey: "Optional attachment",
        optional: true,
      },
    ],
  },
  {
    id: "system_fields",
    label: "System / Metadata",
    icon: "wrench",
    fields: [
      { key: "formId",           label: "Form ID",           selector: "#guideContainer-rootPanel-panel_1231489067-guidetextbox___widget",              type: "text", dataKey: "formId",           optional: true },
      { key: "referenceNumber",  label: "Reference Number",  selector: "#guideContainer-rootPanel-panel_1231489067-guidetextbox_393894177___widget",     type: "text", dataKey: "referenceNumber",  optional: true },
      { key: "srn",              label: "SRN",               selector: "#guideContainer-rootPanel-panel_1231489067-guidetextbox_1241688170___widget",     type: "text", dataKey: "srn",              optional: true },
      { key: "userId",           label: "User ID",           selector: "#guideContainer-rootPanel-panel_1231489067-guidetextbox_2070870574___widget",     type: "text", dataKey: "userId",           optional: true },
    ],
  },
];

var INC32_FIELDS = INC32_CATEGORIES.flatMap(function (c) {
  return c.fields.map(function (f) { return Object.assign({}, f, { category: c.id, categoryLabel: c.label }); });
});
if (typeof window !== 'undefined') {
  window.INC32_CATEGORIES = INC32_CATEGORIES;
  window.INC32_FIELDS = INC32_FIELDS;
  window.INC32_EXPECTED_FIELDS = INC32_FIELDS.length;
}
} // end idempotency guard
